using System.ComponentModel.DataAnnotations;
using System;

namespace RESTauranter.Models
{
    public abstract class BaseEntity {}
    public class Review : BaseEntity
    {
        [Key]
        public long Id { get; set; }
        
        [Display(Name = "Reviewer Name")]
        [Required]
        public string reviewer { get; set; }

        [Display(Name = "Restaurant Name")]
        // [Required]
        public string restaurant { get; set; }
        
        [Display(Name = "Review")]
        // [Required]
        public string review { get; set; }

        [Display(Name = "Visit Date")]
        [DataType(DataType.DateTime)]
        // [Required]
        public DateTime date { get; set; }

        [Display(Name = "Rating")]
        // [Required]
        public string rating { get; set; }
    }
}